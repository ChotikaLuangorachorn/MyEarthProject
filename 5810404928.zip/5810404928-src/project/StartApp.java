//5810404928 Chotika Luangorachorn
package project;

import controllers.DrawingController;

public class StartApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DrawingController dc = new DrawingController();
		dc.startApp();
	}

}
